//Name: Schulte, Adam
//Email: aschu27@lsu.edu
//Project: PA-1 (Multithreading)
//Instructor: Feng Chen
//Class: cs4103-sp23
//Login ID: cs410366
Adam Schulte 89-332-1700 aschu27@lsu.edu
To Compile type: javac Threads.java
To Run type: java Threads sudoku.txt output.txt
IMPORTANT: Make sure you have an input text file formatted exactly like the example given because I didn't do input verification
It will create a text file called output that can be read using: cat output.txt
