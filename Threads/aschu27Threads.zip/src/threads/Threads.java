
package threads;

import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;

public class Threads {
    public static void main(String[] args) throws FileNotFoundException, IOException{
        
        File sudokuFile = new File(args[0]);
        Scanner sudokuScanner = new Scanner(sudokuFile);
        
        File outputFile = new File(args[1]);
        FileWriter fw = new FileWriter(outputFile);
        
        int[][] sudokuBoard = new int[9][9];
        for(int i = 0; i < 9; i++){
            for(int j = 0; j < 9; j++)
            {
                sudokuBoard[i][j] = sudokuScanner.nextInt();
            }
        }
        
        int[] validRows = {0,0,0,0,0,0,0,0,0};
        int[] validColumns = {0,0,0,0,0,0,0,0,0};
        int[] validSquares = {0,0,0,0,0,0,0,0,0};
        
        RowThread myRowThread = new RowThread();
        myRowThread.run(sudokuBoard, validRows, fw);
        
        ColumnThread myColumnThread = new ColumnThread();
        myColumnThread.run(sudokuBoard, validColumns, fw);
        
        SquareThread mySquareThread = new SquareThread();
        mySquareThread.run(sudokuBoard, validSquares, fw);
        
        int numValidRows = 0;
        int numValidColumns = 0;
        int numValidSquares = 0;
        
        for(int y = 0; y < 9; y++)
        {
            numValidRows += validRows[y];
            numValidColumns += validColumns[y];
            numValidSquares += validSquares[y];
        }
        
        fw.write("Valid rows: " + numValidRows + "\n");
        fw.write("Valid columns: " + numValidColumns + "\n");
        fw.write("Valid subgrids: " + numValidSquares + "\n");
        
        int totalValids = numValidRows + numValidColumns + numValidSquares;
        if(totalValids == 27)
        {
            fw.write("This Sudoku solution is: Valid\n");
        }
        else{
            fw.write("This Sudoku solution is: Invalid\n");
        }
        
        fw.close();
    }
    public static boolean isValid(int[] array, int number){
        int counter = 0;
        for(int i = 0; i < 9; i++)
        {
            if(array[i] == number)
            {
                counter++;
            }
        }
        return counter == 1;
    }
    public static void mergeSort(int[] a, int n) {
        if (n < 2) 
        {
            return;
        }
        int mid = n / 2;
        int[] l = new int[mid];
        int[] r = new int[n - mid];

        for (int i = 0; i < mid; i++) 
        {
            l[i] = a[i];
        }
        for (int i = mid; i < n; i++) 
        {
            r[i - mid] = a[i];
        }
        mergeSort(l, mid);
        mergeSort(r, n - mid);

        merge(a, l, r, mid, n - mid);
    }

    public static void merge(
            int[] a, int[] l, int[] r, int left, int right) {

        int i = 0, j = 0, k = 0;
        while (i < left && j < right) 
        {
            if (l[i] <= r[j]) 
            {
                a[k++] = l[i++];
            } else {
                a[k++] = r[j++];
            }
        }
        while (i < left) 
        {
            a[k++] = l[i++];
        }
        while (j < right) 
        {
            a[k++] = r[j++];
        }
    }
}

class RowThread extends Thread {
    public void run(int[][] sudokuBoard, int[] validRows, FileWriter fw) throws FileNotFoundException, IOException{
        int[] row = new int[10];
        for(int i = 0; i < 9; i++)
        {
            for(int j = 0; j < 9; j++)
            {
                row[j] = sudokuBoard[i][j];
            }
            Threads.mergeSort(row, 9);
            boolean isValid = true;
            int k = 0;
            while(isValid && k < 9)
            {
                if(row[k] != k + 1)
                {
                    isValid = false;
                }
                k++;
            }
            int rowNum = i + 1;
            if(isValid)
            {
                validRows[i] = 1;
                fw.write("[Thread 1] Row " + rowNum + ": Valid\n");
            }
            else
            {
                fw.write("[Thread 1] Row " + rowNum + ": InValid\n");   
            }
        }
    }
}

class ColumnThread extends Thread{
    public void run(int[][] sudokuBoard, int[] validColumns, FileWriter fw) throws FileNotFoundException, IOException{
        int[] column = new int[10];
        for(int i = 0; i < 9; i++)
        {
            for(int j = 0; j < 9; j++)
            {
                column[j] = sudokuBoard[j][i];
            }
            Threads.mergeSort(column, 9);
            boolean isValid = true;
            int k = 0;
            while(isValid && k < 9)
            {
                if(column[k] != k + 1)
                {
                    isValid = false;
                }
                k++;
            }
            int colNum = i + 1;
            if(isValid)
            {
                validColumns[i] = 1;
                fw.write("[Thread 2] Column " + colNum + ": Valid\n");
            }
            else
            {
                fw.write("[Thread 2] Column " + colNum + ": InValid\n");   
            }   
        }
    }
}

class SquareThread extends Thread{
    public void run(int[][] sudokuBoard, int[] validSquares, FileWriter fw) throws FileNotFoundException, IOException{
        int[] square = new int[10];
        for (int h = 0; h < 3; h++) 
        {
            for (int k = 0; k < 3; k++) 
            {
                for (int i = 0; i < 3; i++) 
                {
                    for (int j = 0; j < 3; j++) 
                    {
                        square[(i * 3) + j] = sudokuBoard[(h * 3) + i][(3 * k + j)];
                    }
                }
                Threads.mergeSort(square, 9);
                boolean isValid = true;
                int x = 0;
                while(isValid && x < 0)
                {
                    if(square[x] != x + 1)
                    {
                        isValid = false;
                    }
                    x++;
                }
                if(isValid)
                {
                    validSquares[(h * 3) + k] = 1;
                    fw.write("[Thread 3] SubGrid " + "R"  + (1 + h * 3) + (2 + h * 3) + (3 + h * 3) + "C" + (1 + k * 3) + (2 + k * 3) + (3 + k * 3) + ": Valid\n");
                    
                }
                else
                {
                    fw.write("[Thread 3] SubGrid " + "R"  + (1 + h * 3) + (2 + h * 3) + (3 + h * 3) + "C" + (1 + k * 3) + (2 + k * 3) + (3 + k * 3) + ": InValid\n");   
                }
            }
        }
    }
}

